package com.example.finalquiz;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

	final int q1_ans = R.id.question_1_2;
	final int q2_ans = R.id.question_2_1;
	final String q4_ans = "netflix";
	final int q5_ans = R.id.question_5_1;
	final String q6_ans = "professor";
	final String q7_ans = "rajat";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	public void verifyAns(View v) {

		int corr_Ans = 0;

		if(verify_que_1() ){corr_Ans++;}
		if(verify_que_2() ){ corr_Ans++; }
		if(verify_que_3() ){ corr_Ans++; }
		if(verify_que_4() ){ corr_Ans++; }
		if(verify_que_5() ){ corr_Ans++; }
		if(verify_que_6() ){ corr_Ans++; }
		if(verify_que_7() ){ corr_Ans++; }

		Toast.makeText(this, "You got " + corr_Ans+"/7 answers right.",Toast.LENGTH_SHORT).show();

	}

	private boolean verify_que_1() {
		RadioGroup rg = findViewById(R.id.que_1_rg);

		if(rg.getCheckedRadioButtonId() == q1_ans) {
			return true;
		}

		return false;
	}

	private boolean verify_que_2() {
		RadioGroup rg = findViewById(R.id.que_2_rg);

		if(rg.getCheckedRadioButtonId() == q2_ans) {
			return true;
		}

		return false;
	}

	private boolean verify_que_3() {
		CheckBox c1 = findViewById(R.id.que_3_cb_1);
		CheckBox c2 = findViewById(R.id.que_3_cb_2);
		CheckBox c3 = findViewById(R.id.que_3_cb_3);

		if (c1.isChecked() && c2.isChecked() && c3.isChecked()) {
			return true;
		}

		return false;
	}

	private boolean verify_que_4() {
		EditText et = findViewById(R.id.que_4_et);

		return et.getText().toString().equalsIgnoreCase(q4_ans);
	}

	private boolean verify_que_5() {
		RadioGroup rg = findViewById(R.id.que_5_rg);

		if(rg.getCheckedRadioButtonId() == q5_ans) {
			return true;
		}

		return false;
	}

	private boolean verify_que_6() {
		EditText et = findViewById(R.id.que_6_et);

		return et.getText().toString().equalsIgnoreCase(q6_ans);
	}

	private boolean verify_que_7() {
		EditText et = findViewById(R.id.que_7_et);

		return et.getText().toString().equalsIgnoreCase(q7_ans);
	}
}